package com.cristiano.raycast;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;

public class MainActivity extends  Activity { 

    private int Largura;
    private int Altura;
    
    private TextView Player_Pos;
    
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        
        final LinearLayout p1 = new LinearLayout(this);
        p1.setBackgroundColor(Color.TRANSPARENT);
        p1.setPadding(0,0,0,0);
        p1.setOrientation(LinearLayout.VERTICAL);
        
        final LinearLayout p2 = new LinearLayout(this);
        p2.setBackgroundColor(Color.BLACK);
        p2.setPadding(0,0,0,0);
        p2.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        p2.setLayoutParams(new LinearLayout.LayoutParams(-1,50));

        Player_Pos = new TextView(this);
        Player_Pos.setTextColor(Color.WHITE);
        Player_Pos.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        Player_Pos.setText("Pos X = null Pos Y = null");
        
        gameEngine = new GameEngine();
        SurfaceView view = new GameView(this);
        
        p1.addView(p2);
        p2.addView(Player_Pos);
        p1.addView(view);
        setContentView(p1);
        getActionBar().hide();
    }

    GameEngine gameEngine;
    {
    }

    public static void stopThread(Thread thread) 
    {
        boolean retry = true;
        while (retry) 
        {
            try 
            {
                thread.join();
                retry = false;
            } 
            catch (InterruptedException e) {}
        }
    }

    public class GameEngine{

        private Player player;
        private List<Wall> walls = new ArrayList<>();

        public GameEngine(){

            for(int i = 0; i < 5/*Quantidade de linhas na tela*/; i++){

                int x1 = getRandom((0), (getDisplayWidthPixels(getApplicationContext())));
                int x2 = getRandom((0), (getDisplayWidthPixels(getApplicationContext())));

                int y1 = getRandom((0), (getDisplayHeightPixels(getApplicationContext())));
                int y2 = getRandom((0), (getDisplayHeightPixels(getApplicationContext())));
                
                walls.add(new Wall(x1, x2,y1,y2));
            }

            Largura = getDisplayWidthPixels(getApplicationContext());
            Altura = getDisplayHeightPixels(getApplicationContext());
            
            walls.add(new Wall(0,0, Largura,0));
            walls.add(new Wall(0,0, 0,Altura));
            walls.add(new Wall(Largura,0, Largura,Altura));
            walls.add(new Wall(0,Altura, Largura,Altura));
            walls.add(new Wall(0,Altura,Altura,Altura));
            
            walls.add(new Wall(0,1180,387,806));
            
            player = new Player();
        }

        public void draw(Canvas canvas){
            for(Wall wall : walls){
                wall.draw(canvas);
            }
            player.look(canvas, walls);
        }
        
        public void onTouch(int x, int y){
            player.setPos((float)x,(float)y);
            Player_Pos.setText("Pos X = " + String.valueOf((long)(x)) + " Pos Y = " + String.valueOf((long)(y)));
        }
    }

    public class GameView extends SurfaceView implements SurfaceHolder.Callback{
        private Context context;

        private DisplayThread displayThread;
        public GameView(Context context){
            super(context);
            this.context = context;
            init();
        } 

        private void init(){
            SurfaceHolder holder = getHolder();
            holder.addCallback( this);
            displayThread = new DisplayThread(holder);
            setFocusable(true);
        }
        
        public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
        }
        
        public void surfaceDestroyed(SurfaceHolder arg0) {
            displayThread.SetIsRunning(false);  
            stopThread(displayThread);
        }
        
        public void surfaceCreated(SurfaceHolder arg0) 
        {
            if(!displayThread.IsRunning())
            {
                displayThread = new DisplayThread(getHolder());
                displayThread.start();
            }
            else
            {
                displayThread.start();
            }
        }
        
        public boolean onTouchEvent(MotionEvent event){
            
            int x = (int) event.getX();
            int y = (int) event.getY();
            
            gameEngine.onTouch(x,y);
            
            return true;
        }
    }
    
    public class DisplayThread extends Thread{
        SurfaceHolder surfaceHolder;
        Paint backgroundPaint;

        long sleepTime;

        final long DELAY = 4;

        boolean isOnRun;
        public DisplayThread(SurfaceHolder surfaceHolder){

            this.surfaceHolder = surfaceHolder;
            
            backgroundPaint = new Paint();
            backgroundPaint.setColor(Color.BLACK);
            
            isOnRun = true;
        }
        
        public void run() 
        {
            while (isOnRun) 
            {
                Canvas canvas = surfaceHolder.lockCanvas(null);

                if (canvas != null) 
                {
                    synchronized (surfaceHolder) 
                    {
                        canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), backgroundPaint);
                        gameEngine.draw(canvas);
                    }
                    
                    surfaceHolder.unlockCanvasAndPost(canvas);
                }

                try 
                {
                    Thread.sleep(DELAY);
                } 
                catch (InterruptedException ex) 
                {
                }
            }
        }
        public boolean IsRunning()
        {
            return isOnRun;
        }

        public void SetIsRunning(boolean state)
        {
            isOnRun = state;
        }
    }

    public class Wall{
        public Point a;
        public Point b;
        private Paint wallPaint = new Paint();
        public Wall(int x1, int y1, int x2,int y2){

            a = new Point(x1,y1);
            b = new Point(x2,y2);

            wallPaint.setColor(Color.GREEN);
            wallPaint.setStrokeWidth(getDip(getApplicationContext(), 2));
        }
        public void draw(Canvas canvas){
            canvas.drawLine(a.x, a.y, b.x, b.y, wallPaint);
        }
    }

    public class Ray{
        private PointF pos;
        private PointF dir;
        public Ray(PointF pos, double angle){

            this.pos= pos;

            float x =  (float)Math.cos(angle);
            float y =  (float)Math.sin(angle);

            dir = new PointF(x,y);
            
        }
        
        public void pointTo(int x, int y){
            dir.x =  normalise(x - pos.x, 0f, 1f);
            dir.y =  normalise(y - pos.y, 0f, 1f);
        }
        public PointF cast(Wall wall){

            int x1 = wall.a.x;
            int x2 = wall.b.x;
            int y1 = wall.a.y;
            int y2 = wall.b.y;

            float x3 = pos.x;
            float y3 = pos.y;
            float x4 = pos.x + dir.x;
            float y4 = pos.y + dir.y;

            float den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);

            if(den == 0){
                return null;
            }

            float t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den;
            float u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / den;

            if (t >0  && t < 1 && u > 0) {

                float x =  x1 + t * (x2 - x1);
                float y =  y1 + t * (y2 - y1);

                return new PointF(x,y);
            }
            return null;
        }
    }

    public static float normalise(float val, float min, float max) {
        if(max - min == 0) return 1;
        return (val - min) / (max - min);
    }

    public class Player{
        private PointF pos;
        private List<Ray> rays;

        private Paint paint = new Paint();
        public Player(){

            pos = new PointF(360, 540);

            rays = new ArrayList<>();

            for(int a = 0; a < 360; a += 1){
                rays.add(new Ray(pos, Math.toRadians(a)));
            }
            paint.setAntiAlias(false);
            paint.setColor(Color.WHITE);
        }
        
        public void setPos(float x, float y){
            this.pos.set(x,y);
        }
        public void look(Canvas canvas, List<Wall> walls){
            for(Ray ray : rays){
                double record = Double.POSITIVE_INFINITY;
                PointF closest = null;
                for(Wall wall : walls){
                    PointF intersect = ray.cast(wall);
                    if(intersect != null){
                        double dist = Math.hypot(this.pos.x -intersect.x, this.pos.y - intersect.y);
                        if(dist < record){
                            record = dist;
                            closest = intersect;
                        }
                        record = Math.min(dist, record);

                    }
                }
                if(closest != null){
                    paint.setAlpha(100);
                    canvas.drawLine(this.pos.x, this.pos.y, closest.x, closest.y, paint);
                }
            }
        }
    }
    
    public int getRandom(int min, int max) {
        Random random = new Random();
        return random.nextInt(max - min + 1) + min;
    }
    
    public float getDip(Context context, int input) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, input, context.getResources().getDisplayMetrics());
    }

    public int getDisplayWidthPixels(Context context) {
        return context.getResources().getDisplayMetrics().widthPixels;
    }

    public int getDisplayHeightPixels(Context context) {
        return context.getResources().getDisplayMetrics().heightPixels;
    }
}

